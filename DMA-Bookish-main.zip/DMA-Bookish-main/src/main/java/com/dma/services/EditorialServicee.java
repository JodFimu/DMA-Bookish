/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dma.services;

import com.dma.model.Editorial;
import java.util.List;

/**
 *
 * @author informatica
 */
public interface EditorialServicee {
    
    public void crearEditorial(Editorial editorial);
    
    public List<Editorial> listarEditoriales();
    
    public Editorial buscarEditorial(int idEditorial);
    
    public void editarEditorial(Editorial editorial);
    
    public void eliminarEditorial(int idEditorial);
}

