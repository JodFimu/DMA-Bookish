/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dma.services;

import com.dma.model.Editorial;
import com.dma.util.JpaUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class EditorialService implements EditorialServicee {
    
    private EntityManager em;
    
    public EditorialService() {
        this.em = JpaUtil.getEntityManager();
    }

    @Override
    public void crearEditorial(Editorial editorial) {
       EntityTransaction transaction = em.getTransaction();
       try {
           transaction.begin();
           em.persist(editorial);
           transaction.commit();
       } catch(Exception e) {
           if(transaction.isActive()) {
               transaction.rollback();
           }
           e.printStackTrace();
       }
    }

    @Override
    public List<Editorial> listarEditoriales() {
        TypedQuery<Editorial> query = em.createQuery("SELECT e FROM Editorial e", Editorial.class);
        return query.getResultList();
    }

    @Override
    public Editorial buscarEditorial(int idEditorial) {
       return em.find(Editorial.class, idEditorial);
    }

    @Override
    public void editarEditorial(Editorial editorial) {
        EntityTransaction transaction = em.getTransaction();
        try {
            transaction.begin();
            em.merge(editorial);
            transaction.commit();
        } catch(Exception e) {
            if(transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    @Override
    public void eliminarEditorial(int idEditorial) {
        Editorial editorial = buscarEditorial(idEditorial);
        if(editorial != null) {
            EntityTransaction transaction = em.getTransaction();
            try {
                transaction.begin();
                em.remove(editorial);
                transaction.commit();
            } catch(Exception e) {
                if(transaction.isActive()) {
                    transaction.rollback();
                }
                e.printStackTrace();
            }
        }
    } 
}
