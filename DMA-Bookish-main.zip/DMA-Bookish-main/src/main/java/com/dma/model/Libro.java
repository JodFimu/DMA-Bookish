package com.dma.model;

public class Libro {

    private int idLibro;
    private String nombre;
    private String sinopsis;
    private String autor;
}
